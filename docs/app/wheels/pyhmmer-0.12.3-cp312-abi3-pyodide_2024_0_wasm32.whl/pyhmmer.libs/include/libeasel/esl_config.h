/* esl_config.h.in  [input to configure]
 * 
 * System-dependent configuration of Easel, by CMake.
 * 
 * This file should be included in all Easel .c files before
 * anything else, because it may set #define's that control
 * behaviour of system includes and system libraries. An example
 * is large file support.
 * 
 */
#ifndef eslCONFIG_INCLUDED
#define eslCONFIG_INCLUDED

/* Version info.
 */
#define EASEL_VERSION "0.49"
#define EASEL_DATE "Aug 2023"
#define EASEL_COPYRIGHT "Copyright (C) 2023 Howard Hughes Medical Institute."
#define EASEL_LICENSE "Freely distributed under the BSD open source license."
#define EASEL_URL "http://bioeasel.org/"

/* Control of debugging instrumentation */
/* #undef eslDEBUGLEVEL */
/* #undef eslENABLE_ASAN */
/* #undef eslENABLE_TSAN */

/* Optional parallel implementation support */
#define eslENABLE_SSE
#define eslENABLE_SSE4
/* #undef eslENABLE_AVX */
/* #undef eslENABLE_AVX512 */
/* #undef eslENABLE_NEON */
/* #undef eslENABLE_VMX */

/* #undef eslHAVE_NEON_AARCH64 */

/* #undef eslENABLE_CUDA */

/* #undef HAVE_FLUSH_ZERO_MODE */
/* #undef HAVE_DENORMALS_ZERO_MODE */

/* #undef HAVE_MPI */
/* #undef HAVE_PTHREAD */

/* Programs */
/* #undef HAVE_GZIP */

/* Libraries */
/* #undef HAVE_LIBGSL */

/* Headers */
#ifndef HAVE_ENDIAN_H
#define HAVE_ENDIAN_H 1
#endif
#ifndef HAVE_INTTYPES_H
#define HAVE_INTTYPES_H 1
#endif
#ifndef HAVE_STDINT_H
#define HAVE_STDINT_H 1
#endif
#ifndef HAVE_UNISTD_H
#define HAVE_UNISTD_H 1
#endif
#ifndef HAVE_STRINGS_H
#define HAVE_STRINGS_H 1
#endif
#ifndef HAVE_NETINET_IN_H
#define HAVE_NETINET_IN_H 1	/* On FreeBSD, you need netinet/in.h for struct sockaddr_in */
#endif
#ifndef HAVE_SYS_MMAN_H
#define HAVE_SYS_PARAM_H  1
#endif
#ifndef HAVE_SYS_PARAM_H
#define HAVE_SYS_PARAM_H 1
#endif
#ifndef HAVE_SYS_STAT_H
#define HAVE_SYS_STAT_H 1
#endif
#ifndef HAVE_SYS_SYSCTL_H
/* #undef HAVE_SYS_SYSCTL_H */
#endif
#ifndef HAVE_SYS_TYPES_H
#define HAVE_SYS_TYPES_H 1
#endif
#ifndef HAVE_SYSLOG_H
#define HAVE_SYSLOG_H  1
#endif

/* Types */
/* #undef WORDS_BIGENDIAN */
/* #undef int8_t */
/* #undef int16_t */
/* #undef int32_t */
/* #undef int64_t */
/* #undef uint8_t */
/* #undef uint16_t */
/* #undef uint32_t */
/* #undef uint64_t */
/* #undef off_t */

/* Compiler characteristics */
/* #undef HAVE_FUNC_ATTRIBUTE_NORETURN */
/* #undef HAVE_FUNC_ATTRIBUTE_FORMAT */

/* Functions */
#ifndef HAVE_ALIGNED_ALLOC
#define HAVE_ALIGNED_ALLOC   1  // esl_alloc
#endif
#ifndef HAVE_ERFC
#define HAVE_ERFC            1           // esl_stats
#endif
#ifndef HAVE_GETCWD
/* #undef HAVE_GETCWD */
#endif
#ifndef HAVE_GETPID
#define HAVE_GETPID          1         // esl_random
#endif
#ifndef HAVE__MM_MALLOC
/* #undef HAVE__MM_MALLOC */
#endif
#ifndef HAVE_POPEN
#define HAVE_POPEN           1          // various file parsers that check for piped input
#endif
#ifndef HAVE_POSIX_MEMALIGN
#define HAVE_POSIX_MEMALIGN  1 // esl_alloc
#endif
#ifndef HAVE_STRCASECMP
#define HAVE_STRCASECMP      1     // easel::esl_strcasecmp()
#endif
#ifndef HAVE_STRSEP
#define HAVE_STRSEP          1         // easel::esl_strsep()
#endif
#ifndef HAVE_SYSCONF
#define HAVE_SYSCONF         1        // esl_threads, asking system for cpu number
#endif
#ifndef HAVE_SYSCTL
/* #undef HAVE_SYSCTL */
#endif
#ifndef HAVE_TIMES
#define HAVE_TIMES           1          // esl_stopwatch
#endif
#ifndef HAVE_FSEEKO
#define HAVE_FSEEKO
#endif

/* System services */
/* #undef _FILE_OFFSET_BITS */
/* #undef _LARGE_FILES */
/* #undef _LARGEFILE_SOURCE */

 
/* Function behavior */
/* #undef eslSTOPWATCH_HIGHRES */

#endif /*eslCONFIG_INCLUDED*/

