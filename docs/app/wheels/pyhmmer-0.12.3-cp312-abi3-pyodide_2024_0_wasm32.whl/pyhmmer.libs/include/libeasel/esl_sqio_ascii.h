/* Unaligned ascii sequence file i/o.
 */
#ifndef eslSQIO_ASCII_INCLUDED
#define eslSQIO_ASCII_INCLUDED
#include <esl_config.h>

#include <stdio.h>
#ifdef HAVE_SYS_TYPES_H
#include <sys/types.h>
#endif

#include "esl_msa.h"
#include "esl_msafile.h"
#include "esl_sq.h"
#include "esl_sqio.h"

/* set the max residue count to 1 meg when reading a block */
#define MAX_RESIDUE_COUNT (1024 * 1024)

/* forward declaration */
struct esl_sqio_s;

/* ESL_SQASCII:
 * An open sequence file for reading.
 */
typedef struct esl_sqascii_s {
  
  FILE *fp;           	      /* Open file ptr                            */
  char  errbuf[eslERRBUFSIZE];/* parse error mesg.  Size must match msa.h */

  int   do_gzip;	      /* TRUE if we're reading from gzip -dc pipe */
  int   do_stdin;	      /* TRUE if we're reading from stdin         */
  int   do_buffer;            /* TRUE if we're reading from a buffer      */

  /* all input first gets buffered in memory; this gives us enough
   * recall to use Guess*() functions even in nonrewindable streams
   */
  char    *mem;		      /* buffered input                           */
  int      allocm;	      /* <mem> size, multiples of eslREADBUFSIZE  */
  int      mn;		      /* number of chars in <mem> (up to allocm)  */
  int      mpos;	      /* pos of next <buf> to load from <mem>     */
  off_t    moff;	      /* disk offset to start of <mem>            */
  int      is_recording;      /* TRUE if we need to keep buffering more   */

  /* input is either character-based [fread()] or line-based (esl_fgets())*/
  char    *buf;		      /* buffer for fread() or fgets() input      */
  off_t    boff;	      /* disk offset to start of buffer           */
  int      balloc;	      /* allocated size of buf                    */
  int      nc;		      /* #chars in buf (usually full, less at EOF)*/ 
  int      bpos;	      /* current position in the buffer (0..nc-1) */
  int64_t  L;		      /* #residues seen so far in current seq     */
  int64_t  linenumber;	      /* What line of the file  (1..N; -1=unknown)*/
  off_t    bookmark_offset;   /* bookmark fwd position before reversing...*/
  int64_t  bookmark_linenum;  /* in both linenumber and disk offset       */

  /* Format-specific configuration                                           */
  int   is_linebased;	      /* TRUE for fgets() parsers; FALSE for fread() */
  int   eof_is_ok;	      /* TRUE if record can end on EOF               */
  int  (*parse_header)(struct esl_sqio_s *, ESL_SQ *sq);
  int  (*skip_header) (struct esl_sqio_s *, ESL_SQ *sq);
  int  (*parse_end)   (struct esl_sqio_s *, ESL_SQ *sq); 

  /* MSA files can be read as sequential seq files.                     */
  ESL_MSAFILE  *afp;	      /* open ESL_MSAFILE for reading           */
  ESL_MSA      *msa;	      /* preloaded alignment to draw seqs from  */
  int           idx;	      /* index of next seq to return, 0..nseq-1 */

  /* SSI indexes allow fast random access of records in a seq file          */
  char    *ssifile;	      /* path to expected SSI index file            */
  int      rpl;		      /* residues per line in file; -1=unset 0=inval*/
  int      bpl;		      /* bytes per line in file; -1=unset, 0=inval  */
  int      currpl;	      /* residues on current line (-1=unknown)      */
  int      curbpl;	      /* bytes on current line    (-1=unknown)      */
  int      prvrpl;	      /* residues on previous line                  */
  int      prvbpl;	      /* bytes on previous line                     */
  ESL_SSI *ssi;		      /* open ESL_SSI index, or NULL if none        */
} ESL_SQASCII_DATA;


extern int  esl_sqascii_Open(char *seqfile, int format, struct esl_sqio_s *sqfp);
extern int  esl_sqascii_WriteFasta(FILE *fp, ESL_SQ *s, int update);
extern int  esl_sqascii_Parse(char *buf, int size, ESL_SQ *s, int format);

/* format specific routines */
int   sqascii_GuessFileFormat(struct esl_sqio_s *sqfp, int *ret_fmt);
int   sqascii_Position       (struct esl_sqio_s *sqfp, off_t offset);
void  sqascii_Close          (struct esl_sqio_s *sqfp);
int   sqascii_SetDigital     (struct esl_sqio_s *sqfp, const ESL_ALPHABET *abc);
int   sqascii_GuessAlphabet  (struct esl_sqio_s *sqfp, int *ret_type);
int   sqascii_Read           (struct esl_sqio_s *sqfp, ESL_SQ *sq);
int   sqascii_ReadInfo       (struct esl_sqio_s *sqfp, ESL_SQ *sq);
int   sqascii_ReadSequence   (struct esl_sqio_s *sqfp, ESL_SQ *sq);
int   sqascii_ReadWindow     (struct esl_sqio_s *sqfp, int C, int W, ESL_SQ *sq);
int   sqascii_ReadBlock      (struct esl_sqio_s *sqfp, ESL_SQ_BLOCK *sqBlock, int max_residues, int max_sequences, int max_init_window, int long_target);
int   sqascii_Echo           (struct esl_sqio_s *sqfp, const ESL_SQ *sq, FILE *ofp);

int   sqascii_IsRewindable   (const struct esl_sqio_s *sqfp);
const char *sqascii_GetError (const struct esl_sqio_s *sqfp);

int   sqascii_OpenSSI         (struct esl_sqio_s *sqfp, const char *ssifile_hint);
int   sqascii_PositionByKey   (struct esl_sqio_s *sqfp, const char *key);
int   sqascii_PositionByNumber(struct esl_sqio_s *sqfp, int which);
int   sqascii_Fetch           (struct esl_sqio_s *sqfp, const char *key, ESL_SQ *sq);
int   sqascii_FetchInfo       (struct esl_sqio_s *sqfp, const char *key, ESL_SQ *sq);
int   sqascii_FetchSubseq     (struct esl_sqio_s *sqfp, const char *source, int64_t start, int64_t end, ESL_SQ *sq);

/* Internal routines shared by parsers. */
int  loadmem  (struct esl_sqio_s *sqfp);
int  loadbuf  (struct esl_sqio_s *sqfp);
int  nextchar (struct esl_sqio_s *sqfp, char *ret_c);
int  seebuf   (struct esl_sqio_s *sqfp, int64_t maxn, int64_t *opt_nres, int64_t *opt_endpos);
void addbuf   (struct esl_sqio_s *sqfp, ESL_SQ *sq, int64_t nres);
void skipbuf  (struct esl_sqio_s *sqfp, int64_t nskip);
int  read_nres(struct esl_sqio_s *sqfp, ESL_SQ *sq, int64_t nskip, int64_t nres, int64_t *opt_actual_nres);
int  skip_whitespace(struct esl_sqio_s *sqfp);

/* EMBL format; also UniProt, TrEMBL */
void config_embl(struct esl_sqio_s *sqfp);
void inmap_embl (struct esl_sqio_s *sqfp, const ESL_DSQ *abc_inmap);
int  header_embl(struct esl_sqio_s *sqfp, ESL_SQ *sq);
int  skip_embl  (struct esl_sqio_s *sqfp, ESL_SQ *sq);
int  end_embl   (struct esl_sqio_s *sqfp, ESL_SQ *sq);

/* GenBank format; also DDBJ */
void config_genbank(struct esl_sqio_s *sqfp);
void inmap_genbank (struct esl_sqio_s *sqfp, const ESL_DSQ *abc_inmap);
int  header_genbank(struct esl_sqio_s *sqfp, ESL_SQ *sq);
int  skip_genbank  (struct esl_sqio_s *sqfp, ESL_SQ *sq);
int  end_genbank   (struct esl_sqio_s *sqfp, ESL_SQ *sq);

/* FASTA format */
void config_fasta(struct esl_sqio_s *sqfp);
void inmap_fasta (struct esl_sqio_s *sqfp, const ESL_DSQ *abc_inmap);
int  header_fasta(struct esl_sqio_s *sqfp, ESL_SQ *sq);
int  skip_fasta  (struct esl_sqio_s *sqfp, ESL_SQ *sq);
int  end_fasta   (struct esl_sqio_s *sqfp, ESL_SQ *sq);

/* daemon format */
void config_daemon(struct esl_sqio_s *sqfp);
void inmap_daemon (struct esl_sqio_s *sqfp, const ESL_DSQ *abc_inmap);
int  end_daemon   (struct esl_sqio_s *sqfp, ESL_SQ *sq);

/* HMMPGMD format */
int  fileheader_hmmpgmd(struct esl_sqio_s *sqfp);

#endif /*eslSQIO_ASCII_INCLUDED*/
